# I have created This File----Brijesh
from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')


def analyze(request):
    #Get The Text
    djtext = request.POST.get('text', 'default')
    #  check checkbox value
    removepunc = request.POST.get('removepunc', 'off')
    fullcaps = request.POST.get('fullcaps', 'off')
    newlineremove = request.POST.get('newlineremove', 'off')
    spaceremove = request.POST.get('spaceremove', 'off')
    charcount = request.POST.get('charcount', 'off')


#check which checkbox is on
    if removepunc == "on":
        #analyzed = djtext
        punctuations = '''!()-[]{};:'"\,<>./?@#$^&*_~'''
        analyzed = ""
        for char in djtext:

            if char not in punctuations:
                analyzed = analyzed + char

        params = {'purpose': 'Removed Punctuations', 'analyzed_text': analyzed}
        djtext = analyzed

    # Analyze the text
        #return render(request, 'analyze.html', params)

    if fullcaps == "on":

        analyzed = ""

        for char in djtext:
            analyzed = analyzed + char.upper()
        params = {'purpose': 'Changed To Uppercase', 'analyzed_text': analyzed}
        djtext = analyzed
        #return render(request, 'analyze.html', params)

    if newlineremove == "on":
        analyzed = ""
        for char in djtext:

            if char != "\n" and char!="\r":
                analyzed = analyzed + char
            else:
                print("NO")
        print("pre", analyzed)

        params = {'purpose': 'New Line Removed', 'analyzed_text': analyzed}
        djtext = analyzed
      #  return render(request, 'analyze.html', params)

    if spaceremove == "on":
        analyzed = ""
        for index, char in enumerate(djtext):

            if not(djtext[index] == " " and djtext[index+1] == " "):

                analyzed = analyzed + char

        params = {'purpose': 'ExtraSpace Removed', 'analyzed_text':analyzed}
        djtext = analyzed
#        return render(request, 'analyze.html', params)


    if charcount == "on":

        analyzed = ""

        for char in djtext:
            analyzed = analyzed + char.count()

        params = {'purpose': 'Character Count', 'analyzed_text': analyzed}

    if(removepunc!="on" and fullcaps!="on" and newlineremove!= "on" and spaceremove!= "on"):
        return HttpResponse("Error")
    return render(request, 'analyze.html', params)





#def capfirst(request):
 #   return HttpResponse("Capitalize First")


#def newlineremove(request):
 #   return HttpResponse("NewlineRemove")

#def spaceremove(request):
 #   return HttpResponse("Space Remover  <a href = '\'>Back</a>")

#def charcount(request):
#    return HttpResponse("CharCount")